#pragma once
#include "PolynomialCurve.h"
namespace cogra
{
namespace gmca
{
template<class T>
class BezierCurve : public PolynomialCurve<T>
{
public:
    typedef T vector_type;
    typedef typename T::value_type value_type;


    BezierCurve(const std::vector<vector_type>& coefficients)
        : PolynomialCurve<T>::PolynomialCurve(coefficients)
        , m_binomialCoefficients(computeBinomialCoefficients())
    {       
    }

    /// <summary>
    /// Compute and return the bionmial coefficients for the given degreen.
    /// </summary>
    /// <returns></returns>
    std::vector<value_type> computeBinomialCoefficients() const 
    { 
        std::vector<value_type> result(PolynomialCurve<T>::getOrder() - 2, 1);
        // Assignment 1(c) Implement me!
        return result;
    }

    vector_type evaluate(value_type t) const override
    {
        // Assignment 1(d) Implement me!
		return vector_type(0);
    }

    void elevateDegree() 
    {
        // Assignment 3 Implement me!
    }

    std::vector<std::vector<vector_type>> deCasteljau(const std::vector<value_type>& t) const
    {
        // Assignment 2(a) Implement me!
		std::vector<std::vector<vector_type>> result;
        (void)t;        
        return result;
    }


    std::vector<std::vector<vector_type>> deCasteljau(const value_type t) const
    {
        // Assignment 2(a) Implement me!
        std::vector<std::vector<vector_type>> result;
        (void)t;
        return result;
    }



    std::pair<BezierCurve<vector_type>, BezierCurve<vector_type>> subdivide() const
    {
        return std::pair<BezierCurve<vector_type>, BezierCurve<vector_type>>(
            BezierCurve<vector_type>(PolynomialCurve<T>::getCoefficients()),
            BezierCurve<vector_type>(PolynomialCurve<T>::getCoefficients()));
    }


private:
    std::vector<value_type>         m_binomialCoefficients;

};
}
}